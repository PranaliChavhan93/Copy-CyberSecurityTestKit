import AmassParameters from "./Amass";
import Netdiscover from "./Netdiscover";
import ReconParameter from "./Recon";
import OwaspParameter from "./Owasp";
import NmapParameter from "./Nmap";
import Burpsuite from "./Burpsuite";

function ToolParameters({ tool, parameters, setParameters, stageCode, onAdvanceStage }) {
    if(tool?.tool_name === "Amass")
    {
        return (
            <Amass
                tool={tool}
                parameters={parameters}
                setParameters={setParameters}
                stageCode={stageCode}
                onAdvanceStage={onAdvanceStage}
            />
        );
    }

    if(tool?.tool_name === "Sublist3r")
    {
        return (
            <Netdiscover
                tool={tool}
                stageCode={stageCode}
                onAdvanceStage={onAdvanceStage}
            />
        );
    }

    if(tool?.tool_name === "Recon-ng")
    {
        return (
            <Recon
                tool={tool}
                stageCode={stageCode}
                onAdvanceStage={onAdvanceStage}
            />
        );
    }

    if(tool?.tool_name === "OWASP ZWAP")
    {
        return(
            <Owasp
                tool={tool}
                stageCode={stageCode}
                onAdvanceStage={onAdvanceStage}
            />
        )
    }

    if(tool?.tool_name === "Nmap")
    {
        return(
            <Nmap
                tool={tool}
                stageCode={stageCode}
                onAdvanceStage={onAdvanceStage}
            />
        )
    }

    if(tool?.tool_name === "Burp Suite Community Edition")
    {
        return(
            <Burpsuite
                tool={tool}
                stageCode={stageCode}
                onAdvanceStage={onAdvanceStage}
            />
        )
    }

    return (
        <div className="tool-parameter-box">
            <h3> {tool?.tool_name} Configuration </h3>
            { Object.keys(parameters || {}).length === 0 ?
                ( <p> Pending... </p> )
                :
                (
                    <div className="parameter-grid">
                    {
                        Object.keys(parameters).map((key)=>(
                            <div
                                className="parameter-field"
                                key={key}
                            >
                                <label>{key}</label>
                                { typeof parameters[key] === "boolean"
                                    ?
                                    (
                                        <input
                                            type="checkbox"
                                            checked={
                                                parameters[key]
                                            }
                                            onChange={(e)=>{
                                                setParameters({
                                                    ...parameters,
                                                    [key]:
                                                    e.target.checked
                                                });
                                            }}
                                        />
                                    )
                                    :
                                    (
                                        <input
                                            type="text"
                                            value={
                                                parameters[key] || ""
                                            }
                                            onChange={(e)=>{
                                                setParameters({
                                                    ...parameters,
                                                    [key]:
                                                    e.target.value
                                                });
                                            }}
                                        />
                                    )
                                }
                            </div>
                        ))
                    }
                    </div>
                )
            }
        </div>
    );
}

export default ToolParameters;